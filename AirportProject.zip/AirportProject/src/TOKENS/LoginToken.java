package TOKENS;

/**
 * This class represents the permissions of a user.
 */
public class LoginToken {
    final long id;
    final String name;
    final int role;

    public LoginToken(long id, String name, int role) {
        this.id = id;
        this.name = name;
        this.role = role;
    }

    @Override
    public String toString() {
        return "LoginToken{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", role=" + role +
                '}';
    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getRole() {
        return role;
    }
}
