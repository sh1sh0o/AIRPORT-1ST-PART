package POCOS;
/**
 * This class represents a record of "Countries" table in the database
 */
public class CountryPOCO implements POCO{
    int id;
    String name;

    public CountryPOCO() {
    }

    public CountryPOCO(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "CountryPOCO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
