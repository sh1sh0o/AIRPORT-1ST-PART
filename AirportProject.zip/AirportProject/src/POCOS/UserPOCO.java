package POCOS;
/**
 * This class represents a record of "Users" table in the database
 */
public class UserPOCO implements POCO{
    long Id;
    String Username;
    String Password;
    String Email;
    int User_Role;

    public UserPOCO() {
    }

    public UserPOCO(long id, String user_Name, String password, String email, int user_Role) {
        Id = id;
        Username = user_Name;
        Password = password;
        Email = email;
        User_Role = user_Role;
    }

    public void setUser_Role(int user_Role) {
        User_Role = user_Role;
    }

    public void setId(long id) {
        Id = id;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public long getId() {
        return Id;
    }

    public String getUsername() {
        return Username;
    }

    public String getPassword() {
        return Password;
    }

    public String getEmail() {
        return Email;
    }

    public int getUser_Role() {
        return User_Role;
    }

    @Override
    public String toString() {
        return "UserPOCO{" +
                "Id=" + Id +
                ", Username='" + Username + '\'' +
                ", Password='" + Password + '\'' +
                ", Email='" + Email + '\'' +
                ", User_Role=" + User_Role +
                '}';
    }
}
