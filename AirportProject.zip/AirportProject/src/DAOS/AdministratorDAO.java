package DAOS;

import POCOS.AdministratorPOCO;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * This class is being use for interfacing with the "Administrators" table in the database
 */
public class AdministratorDAO implements DAO<AdministratorPOCO> {
    private PostgresqlConnection connection=new PostgresqlConnection();
    private ArrayList<AdministratorPOCO> list= new ArrayList<>();
    private String db = "AirPortDB";
    private Connection con = connection.getConnection(db,"791988ss");
    private Statement statement = connection.getStatement();



    @Override
    public Object Get(long id) {
        AdministratorPOCO poco=new AdministratorPOCO();
        try{
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Administrators\"\n" +
                    "where \"Administrators\".\"Id\"="+id);
            result.next();
            poco.setId(result.getInt("Id"));
            poco.setFirst_Name(result.getString("First_Name"));
            poco.setLast_Name(result.getString("Last_Name"));
            poco.setUser_Id(result.getLong("User_Id"));
            result.close();
        }catch (Exception e){

        }
        return poco;
    }

    @Override
    public ArrayList<AdministratorPOCO> GetAll() {
        list.clear();
        try {
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Administrators\"");
            while (result.next()){
                AdministratorPOCO p1=new AdministratorPOCO(result.getInt("Id"),result.getString("First_Name"),result.getString("Last_Name"),result.getLong("User_Id"));
                list.add(p1);
            }
            result.close();
        }catch (Exception e){

        }

        return list;
    }

    @Override
    public boolean Add(AdministratorPOCO o) {

        try {
            var result = statement.executeUpdate("insert into \"Administrators\"(\"First_Name\",\n" +
                    "\"Last_Name\")\n" +
                    "values(\n" +
                    "\'"+o.getFirst_Name()+"\'"+","+
                    "\'"+o.getLast_Name()+"\'"+
                    "\t\n" +
                    ")");
return true;

        }catch (Exception e){
            System.out.println("error-add administrator");
return false;
        }
    }

    @Override
     public void Remove(AdministratorPOCO o) {
        if(o==null)
            return;
        try {
           var result = statement.executeUpdate("delete  from \"Administrators\"\n" +
                    "where \"Id\"="+o.getId());


        }catch (Exception e){

        }
    }

    @Override
    public void Update(AdministratorPOCO o) {
        if(o==null)
            return;
        try {
            var result = statement.executeUpdate("UPDATE \"Administrators\"\n" +
                    "SET  \"First_Name\" =" +"\'"+o.getFirst_Name()+"\'"+",\n" +
                    "\"Last_Name\"="+"\'"+o.getLast_Name()+"\'"+",\"User_Id\"="+o.getUser_Id() +"\n"+
                    "where \"Id\"="+o.getId());


        }catch (Exception e){
            System.out.println("error-update administrator");
            e.printStackTrace();
        }

    }

    /**
     * Returns an Administrator POCO by his user id.
     * @param id The id of the wanted Administrator.
     * @return an Administrator POCO by his user id.
     */
    public AdministratorPOCO get_administrator_by_user_id(long id){
        AdministratorPOCO poco=new AdministratorPOCO();
        try{
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Administrators\"\n" +
                    "where \"Administrators\".\"User_Id\"="+id);
            result.next();
            poco.setId(result.getInt("Id"));
            poco.setFirst_Name(result.getString("First_Name"));
            poco.setLast_Name(result.getString("Last_Name"));
            poco.setUser_Id(result.getLong("User_Id"));
            result.close();
        }catch (Exception e){

        }
        return poco;
    }

    /**
     * Returns an administrator by his full name.
     * @param first_name The administrator's first name.
     * @param last_name The administrator's last name.
     * @return an administrator by his full name.
     */
    public AdministratorPOCO get_administrator_by_full_name(String first_name,String last_name){
        AdministratorPOCO poco=new AdministratorPOCO();
        try{
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Administrators\"\n" +
                    "where \"Administrators\".\"First_Name\"=\'"+first_name+"\'\n"+
                    "and \"Administrators\".\"Last_Name\"="+"\'"+last_name+"\'");
            result.next();
            poco.setId(result.getInt("Id"));
            poco.setFirst_Name(result.getString("First_Name"));
            poco.setLast_Name(result.getString("Last_Name"));
            poco.setUser_Id(result.getLong("User_Id"));
            result.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("error- get_administrator_by_full_name");
        }
        return poco;
    }

}
