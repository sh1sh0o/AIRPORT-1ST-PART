package DAOS;

import POCOS.CustomerPOCO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
/**
 * This class is being use for interfacing with the "Customers" table in the database
 */
public class CustomerDAO implements DAO<CustomerPOCO>{
    private PostgresqlConnection connection = new PostgresqlConnection();
    private ArrayList<CustomerPOCO> list = new ArrayList<>();
    private String db = "AirPortDB";
    private Connection con = connection.getConnection(db,"791988ss");
    private Statement statement = connection.getStatement();



    @Override
    public Object Get(long id) {
        CustomerPOCO poco = new CustomerPOCO();
        try {
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Customers\"\n" +
                    "where \"Customers\".\"Id\"=" + id);
            result.next();
            poco.setId(result.getInt("Id"));
            poco.setFirst_Name(result.getString("First_Name"));
            poco.setLast_Name(result.getString("Last_Name"));
            poco.setAddress(result.getString("Address"));
            poco.setPhone_No(result.getString("Phone_No"));
            poco.setCredit_Card_No(result.getString("Credit_Card_No"));
            poco.setUser_Id(result.getLong("User_Id"));
            result.close();
        } catch (Exception e) {

        }

        return poco;
    }


    @Override
    public ArrayList<CustomerPOCO> GetAll() {
        try {
            list.clear();
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Customers\"");
            while (result.next()) {
                CustomerPOCO p1 = new CustomerPOCO(result.getLong("Id"), result.getString("First_Name")
                ,result.getString("Last_Name"),result.getString("Address")
                , result.getString("Phone_No"), result.getString("Credit_Card_No"), result.getLong("User_Id") );
                list.add(p1);
            }
            result.close();
        } catch (Exception e) {

        }

        return list;
    }

    @Override
    public boolean Add(CustomerPOCO o) {

        try {
            statement.executeUpdate("insert into \"Customers\"(\"First_Name\",\"Last_Name\",\"Address\",\"Phone_No\",\"Credit_Card_No\")\n" +
                    "values('"+o.getFirst_Name()+"','"+o.getLast_Name() +"','"+o.getAddress()+"','"+o.getPhone_No()  +"','"+o.getCredit_Card_No()+"')");
            System.out.println("customer create");
            return true;
        } catch (Exception e) {
            System.out.println("error-add customer");
            return false;
        }
    }

    @Override
    public void Remove(CustomerPOCO o) {
        if(o==null)
            return;
        try {
            var result = statement.executeUpdate("delete  from \"Customers\"\n" +
                    "where \"Id\"=" + o.getId());

        } catch (Exception e) {

        }
    }

    @Override
    public void Update(CustomerPOCO o) {
        if(o==null)
            return;
        try {
            var result = statement.executeUpdate("UPDATE \"Customers\"\n" +
                    "SET \"First_Name\" =" +"\'" + o.getFirst_Name()     +"\'"+
                    ", \"Last_Name\" =" +"\'" + o.getLast_Name()      +"\'"+
                        ",\"Address\" ="+"\'" + o.getAddress()        +"\'"+
                     ", \"Phone_No\" =" +"\'" + o.getPhone_No() +"\'"+
                 ",\"Credit_Card_No\" =" +"\'" + o.getCredit_Card_No() +"\'"+
                      ", \"User_Id\" ="  + o.getUser_Id()+
                        "where \"Id\"=" + o.getId());


        } catch (Exception e) {
            System.out.println("error-update customer");
e.printStackTrace();
        }
    }

    /**
     * Returns a customer POCO by his username.
     * @param username The customer's username.
     * @return a customer POCO by his username.
     */
    public CustomerPOCO get_customer_by_username(String username){
        CustomerPOCO p1=new CustomerPOCO();
        try {
            var result= statement.executeQuery("select * from \"get_customer_by_username\"(\'"+username+"\')");
            result.next();
            p1.setId(result.getLong("Id"));
            p1.setFirst_Name(result.getString("First_Name"));
            p1.setLast_Name(result.getString("Last_Name"));
            p1.setAddress(result.getString("Address"));
            p1.setPhone_No(result.getString("Phone_No"));
            p1.setCredit_Card_No(result.getString("Credis_Card_No"));
            p1.setUser_Id(result.getLong("User_Id"));

            result.close();
        } catch (Exception e) {
            System.out.println("error- get_customer_by_username");
            e.printStackTrace();
        }
        return p1;
    }

    /**
     * Returns a customer POCO by his phone number.
     * @param Phone_No The customer's phone number.
     * @return a customer POCO by his phone number.
     */
    public CustomerPOCO get_customer_by_Phone_No(String Phone_No){
        CustomerPOCO p1=new CustomerPOCO();
        try {
            var result= statement.executeQuery("select * from \"Customers\"\n" +
                    "where \"Phone_No\"='"+Phone_No+"'");
            result.next();
            p1.setId(result.getLong("Id"));
            p1.setFirst_Name(result.getString("First_Name"));
            p1.setLast_Name(result.getString("Last_Name"));
            p1.setAddress(result.getString("Address"));
            p1.setPhone_No(result.getString("Phone_No"));
            p1.setCredit_Card_No(result.getString("Credit_Card_No"));
            p1.setUser_Id(result.getLong("User_Id"));

            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return p1;
    }
//
//    public static void main(String[] args) {
//        CustomerDAO customerDAO=new CustomerDAO();
//        customerDAO.Add(new CustomerPOCO(0,"shai","atias","st","0505058","1919898191981",0));
//        CustomerPOCO customerPOCO=customerDAO.get_customer_by_Phone_No("0505058");
//        System.out.println(customerPOCO);
//        UserPOCO userPOCO=new UserPOCO(0,"roi","gsggnngng","fsd",1);
//        UserDAO userDAO=new UserDAO();
//        userDAO.Add(userPOCO);
//        customerPOCO.setFirst_Name("roi");
//        customerPOCO.setUser_Id(0);
//        customerDAO.Update(customerPOCO);
//        System.out.println(customerPOCO);
//    }


}
