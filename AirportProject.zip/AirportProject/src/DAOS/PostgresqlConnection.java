package DAOS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * This class is the connection between the classes to the postgresql database.
 */
public class PostgresqlConnection {
    private static Connection connection=null;
    private Statement statement=null;

    public PostgresqlConnection(){

    }

    /**
     * Returns a connection.
     * @param dataBaseName The database name.
     * @param password The postgresql password.
     * @return A connection.
     */
    public  Connection getConnection(String dataBaseName,String password) {
        try {
            Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/"+dataBaseName,"postgres",password
            );
            System.out.println("MTA");
        } catch (Exception e) {
            e.printStackTrace();
        }

        return connection;
    }

    /**
     * Returns a statement.
     * @return A statement.
     */
    public Statement getStatement() {
        try {
            statement=connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return statement;
    }
}
