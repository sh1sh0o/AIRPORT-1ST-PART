package DAOS;

import POCOS.UserPOCO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
/**
 * This class is being use for interfacing with the "Users" table in the database
 */
public class UserDAO implements DAO<UserPOCO> {
    private PostgresqlConnection connection = new PostgresqlConnection();
    private ArrayList<UserPOCO> list = new ArrayList<>();
    private String db = "AirPortDB";
    private Connection con = connection.getConnection(db,"791988ss");
    private Statement statement = connection.getStatement();


    @Override
    public Object Get(long id) {
        UserPOCO poco = new UserPOCO();
        try {
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Users\"\n" +
                    "where \"Users\".\"Id\"=" + id);
            poco.setId(result.getInt("Id"));
            poco.setUsername(result.getString("Username"));
            poco.setPassword(result.getString("Password"));
            poco.setEmail(result.getString("Email"));
            poco.setUser_Role(result.getInt("User_Role"));
            result.close();
        } catch (Exception e) {

        }

        return poco;
    }

    @Override
    public ArrayList<UserPOCO> GetAll() {
        try {
            list.clear();
            ResultSet result = statement.executeQuery("select * from\n" +
                    "\"Users\"");
            while (result.next()) {
                UserPOCO p1 = new UserPOCO(result.getInt("Id"), result.getString("Username")
                        ,result.getString("Password"),result.getString("Email"),result.getInt("User_Role"));
                list.add(p1);
            }
            result.close();
        } catch (Exception e) {

        }

        return list;
    }

    @Override
    public boolean Add(UserPOCO o) {

        try {
        statement.executeUpdate("insert into \"Users\"(\"Id\",\"Username\",\"Password\",\n" +
                    "\"Email\",\"User_Role\")" +
                    "values(\n" +o.getId()+","+
                    "\'"+o.getUsername()+"\'"+","+
                    "\'"+o.getPassword()+"\'"+","+
                    "\'"+o.getEmail()+"\'"+","+
                    o.getUser_Role()+
                    "\t\n" +
                    ")");

        return true;
        } catch (Exception e) {
            System.out.println("error-add user");
        }

            return false;

    }

    @Override
    public void Remove(UserPOCO o) {
        try {
            var result = statement.executeUpdate("delete  from \"Users\"\n" +
                    "where \"Id\"=" + o.getId());

        } catch (Exception e) {

        }
    }

    @Override
    public void Update(UserPOCO o) {
        if(o==null)
            return;
        try {
            var result = statement.executeUpdate("UPDATE \"Users\"\n" +
                    "SET \"Id\"=" +o.getId()+
                    "  \"Username\" =" + "\'"+o.getUsername()  +"\'"+
                    ", \"Password\" =" +"\'"+ o.getPassword() +"\'"+
                    ",\"Email\" = "+"\'"+o.getEmail()+"\'"+
                    ",\"User_Role\" ="+"\'"+ o.getUser_Role()+"\'"+
                    "where \"Id\"=" + o.getId());
        } catch (Exception e) {
e.printStackTrace();
        }
    }


    /**
     * Returns a user by its username.
     * @param username The user's username.
     * @return a user by its username.
     */
    public UserPOCO get_user_by_username(String username){
        UserPOCO p1=new UserPOCO();
        try {
            var result=statement.executeQuery("select * from get_user_by_username('"+username+"')");
            result.next();
            p1.setId(result.getLong("Id"));
            p1.setUsername(result.getString("Username"));
            p1.setPassword(result.getString("Password"));
            p1.setEmail(result.getString("Email"));
            p1.setUser_Role(result.getInt("User_Role"));
            result.close();
        } catch (Exception e) {
            System.out.println("error- get_user_by_user_name");
            e.printStackTrace();
        }
        return p1;
    }

}
