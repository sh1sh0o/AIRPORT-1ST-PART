import DAOS.AirlineCompaniesDAO;
import DAOS.FlightDAO;
import FACEADES.AdministratorsFacade;
import FACEADES.AirlineFacade;
import FACEADES.CustomerFacade;
import POCOS.*;
import TOKENS.LoginToken;

public class Main {
    public static void main(String[] args) {
//        CustomerFacade customerFaceade=new CustomerFacade(new LoginToken(35,"shai",1));
//        UserPOCO userPOCO=new UserPOCO(35,"shai","79251453","@shai",1);
//
//        customerFaceade.add_customer(userPOCO, new CustomerPOCO(1,"shai","atias","st","050","458",2));
//        customerFaceade=(CustomerFacade) customerFaceade.login("shai","79251453");
//        FlightDAO flightDAO=new FlightDAO();
//        customerFaceade.remove_ticket(new TicketPOCO(0,3,3));
//        System.out.println( customerFaceade.get_my_tickets());

//        AdministratorsFacade administratorsFacade = new AdministratorsFacade(new LoginToken(0, "israir", 3));
//        UserPOCO userPOCO = new UserPOCO(0, "israir", "1658452", "@israir", 2);
//        administratorsFacade.add_airline(new AirlineCompanyPOCO(0, "israir", 1, 4), userPOCO);
//        AirlineFacade airlineFacade = (AirlineFacade) administratorsFacade.login("israir", "1658452");
//        System.out.println(airlineFacade.get_my_flights());

        AdministratorsFacade administratorsFacade = new AdministratorsFacade(new LoginToken(0, "shir", 3));
        UserPOCO userPOCO=new UserPOCO(0,"shir","nonobnfb","@shir",3);
        administratorsFacade.add_administrator(new AdministratorPOCO(0,"shir","ben",0),userPOCO);
        administratorsFacade=(AdministratorsFacade) administratorsFacade.login("shir","nonobnfb");
        System.out.println(administratorsFacade.get_all_customers());

    }
}
