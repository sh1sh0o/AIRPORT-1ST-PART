package FACEADES;

import DAOS.FlightDAO;
import DAOS.TicketDAO;
import POCOS.CustomerPOCO;
import POCOS.FlightPOCO;
import POCOS.TicketPOCO;
import POCOS.UserPOCO;
import TOKENS.LoginToken;

import java.util.ArrayList;

/**
 * This class operates the customers-allowed functions.
 */
public class CustomerFacade extends AnonymousFacade{
    TicketDAO ticketDAO=new TicketDAO();
    public LoginToken loginToken;

    public CustomerFacade(LoginToken loginToken) {
        this.loginToken = loginToken;
    }
    /**
     * Updates a customer(the customer should be the one to update himself).
     * @param customerPOCO The customer to update.
     */
    public void update_customer(CustomerPOCO customerPOCO){
        if(loginToken.getRole()!=1)
            return;
        if(loginToken.getId()==customerPOCO.getId())
        customerDAO.Update(customerPOCO);
    }

    /**
     * Adds a ticket to the customer.
     * @param ticketPOCO The ticket to add.
     */
    public void add_ticket(TicketPOCO ticketPOCO) {
        if (loginToken.getRole()!= 1)
            return;
        if (flightDAO.update_remaining_tickets(get_flight_by_id(ticketPOCO.getFlight_Id()), -1)) {
            ticketPOCO.setCustomer_Id(loginToken.getId());
            ticketDAO.Add(ticketPOCO);
        }
    }

    /**
     * Removes a ticket to the customer.
     * @param ticketPOCO The ticket to remove.
     */
    public void remove_ticket(TicketPOCO ticketPOCO){
        if(loginToken.getRole()!=1)
            return;
              if(loginToken.getId()==ticketPOCO.getCustomer_Id())
        ticketDAO.Remove(ticketPOCO);
        flightDAO.update_remaining_tickets(get_flight_by_id(ticketPOCO.getFlight_Id()),1);
    }

    /**
     * Returns a ticket POCO list of the customer.
     * @return
     */
    public ArrayList<TicketPOCO> get_my_tickets(){
        if(loginToken.getRole()!=1)
            return null;
        return ticketDAO.get_tickets_by_customer(loginToken.getId());
    }

    @Override
    public String toString() {
        return "CustomerFacade{ " +
                " loginToken=" + loginToken +
                '}';
    }
}
